#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date  : 2019/11/24 11:56
# @Author: yanmiexingkong
# @email : yanmiexingkong@gmail.com
# @File  : quotes_spider.py
from scrapy import cmdline

cmdline.execute('scrapy crawl quotes'.split())
